import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  RotateCcw, 
  ShieldAlert, 
  ShieldCheck, 
  ArrowRight, 
  Sparkles, 
  Sliders, 
  Filter, 
  Play, 
  ExternalLink, 
  Bot, 
  Check, 
  Film, 
  Share2, 
  FileText, 
  Lightbulb, 
  Zap,
  Info,
  TrendingUp,
  Activity,
  Calendar
} from 'lucide-react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend
} from 'recharts';
import { WorkflowRun, QualityCheckDetail, SystemAlert, WorkflowStage } from '../types';

interface ChecksDashboardProps {
  runs: WorkflowRun[];
  alerts: SystemAlert[];
  onRetryRun: (runId: string) => Promise<void>;
  onDismissAlert: (alertId: string) => void;
  onApproveForSocial: (runId: string) => void;
  onNavigateToAgents?: () => void;
}

const STAGE_ICONS: Record<WorkflowStage, any> = {
  'Idea': Lightbulb,
  'Script': FileText,
  'fal.ai': Film,
  'Edit': Sliders,
  'Social Media': Share2
};

const STAGE_ORDER: WorkflowStage[] = ['Idea', 'Script', 'fal.ai', 'Edit', 'Social Media'];

// Generate 30-day historical data for Pipeline Reliability
const generate30DayReliabilityData = () => {
  const data = [];
  const now = new Date();
  
  for (let i = 29; i >= 0; i--) {
    const d = new Date(now);
    d.setDate(d.getDate() - i);
    const dayLabel = d.toLocaleDateString('nl-NL', { day: '2-digit', month: 'short' });
    
    // Day 2 (recent) has the fal.ai incident
    const isIncidentDay = i === 1;
    const failedAttempts = isIncidentDay ? 3 : (i % 7 === 0 ? 2 : (i % 4 === 0 ? 1 : 0));
    const totalRenders = 30 + (i * 3) % 25;
    const successfulRenders = totalRenders - failedAttempts;
    const successRate = parseFloat(((successfulRenders / totalRenders) * 100).toFixed(1));

    data.push({
      date: dayLabel,
      fullDate: d.toLocaleDateString('nl-NL', { day: 'numeric', month: 'long', year: 'numeric' }),
      successRate,
      failedAttempts,
      totalRenders,
      successfulRenders,
    });
  }
  return data;
};

// Custom Dark Tooltip for Recharts
const CustomChartTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const item = payload[0].payload;
    return (
      <div className="bg-zinc-950/95 border border-zinc-800 p-3 rounded-xl shadow-2xl space-y-1.5 text-xs backdrop-blur-md">
        <span className="font-bold text-white block pb-1 border-b border-zinc-800/80">
          {item.fullDate || label}
        </span>
        <div className="flex items-center justify-between space-x-4 text-emerald-400">
          <span>Render Success Rate:</span>
          <strong className="font-mono font-black">{item.successRate}%</strong>
        </div>
        <div className="flex items-center justify-between space-x-4 text-red-400">
          <span>Mislukte Pogingen:</span>
          <strong className="font-mono font-bold">{item.failedAttempts}</strong>
        </div>
        <div className="flex items-center justify-between space-x-4 text-zinc-400 pt-1 border-t border-zinc-800/60 text-[11px]">
          <span>Totaal Verwerkt:</span>
          <strong className="text-white font-mono">{item.totalRenders} runs</strong>
        </div>
      </div>
    );
  }
  return null;
};

export const ChecksDashboard: React.FC<ChecksDashboardProps> = ({
  runs,
  alerts,
  onRetryRun,
  onDismissAlert,
  onApproveForSocial,
  onNavigateToAgents,
}) => {
  const [selectedRunId, setSelectedRunId] = useState<string>(runs[0]?.id || '');
  const [statusFilter, setStatusFilter] = useState<'all' | 'success' | 'failed' | 'running' | 'pending_check'>('all');
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [isRetrying, setIsRetrying] = useState<string | null>(null);

  const reliabilityData = useMemo(() => generate30DayReliabilityData(), []);

  const activeAlerts = alerts.filter(a => !a.dismissed);
  const totalRuns = runs.length;
  const successRuns = runs.filter(r => r.status === 'success').length;
  const failedRuns = runs.filter(r => r.status === 'failed').length;
  const runningRuns = runs.filter(r => r.status === 'running' || r.status === 'pending_check').length;
  const successRate = totalRuns > 0 ? Math.round((successRuns / totalRuns) * 100) : 100;

  // 30-day aggregated metrics
  const avg30DaySuccess = (
    reliabilityData.reduce((acc, d) => acc + d.successRate, 0) / reliabilityData.length
  ).toFixed(1);
  const total30DayFails = reliabilityData.reduce((acc, d) => acc + d.failedAttempts, 0);
  const total30DayRenders = reliabilityData.reduce((acc, d) => acc + d.totalRenders, 0);

  const filteredRuns = runs.filter(run => {
    if (statusFilter !== 'all' && run.status !== statusFilter) return false;
    if (stageFilter !== 'all' && run.currentStage !== stageFilter) return false;
    return true;
  });

  const selectedRun = runs.find(r => r.id === selectedRunId) || runs[0];

  const handleRetry = async (runId: string) => {
    setIsRetrying(runId);
    try {
      await onRetryRun(runId);
    } finally {
      setIsRetrying(null);
    }
  };

  const currentMonthName = useMemo(() => {
    const d = new Date();
    const month = d.toLocaleDateString('nl-NL', { month: 'long' });
    return month.charAt(0).toUpperCase() + month.slice(1);
  }, []);

  const currentMonthTotalVideos = 1248;
  const currentMonthSuccessPercentage = 98.6;
  const currentMonthSuccessVideos = 1231;
  const currentMonthFailedVideos = 17;

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-emerald-950/40 border border-zinc-800 p-6 rounded-3xl flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-2xl">
        <div className="space-y-1.5">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-800/80 flex items-center space-x-1.5 shadow-sm">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Workflow Monitoring &amp; Kwaliteitsvalidatie</span>
            </span>
            <span className="text-xs text-zinc-400 font-mono">Live Pipeline: Idea → fal.ai → Social</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Checks Dashboard &amp; Pijplijn Betrouwbaarheid
          </h2>
          <p className="text-xs text-zinc-400 max-w-xl">
            Real-time monitoring van je geautomatiseerde content-pijplijn. Valideer scripts, fal.ai renders en ondertitels voordat content automatisch wordt gepubliceerd.
          </p>
        </div>

        {onNavigateToAgents && (
          <button
            onClick={onNavigateToAgents}
            className="px-4 py-2.5 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 border border-violet-500/40 text-xs font-bold flex items-center space-x-2 transition-all cursor-pointer shadow-md"
          >
            <Bot className="w-4 h-4 text-violet-400" />
            <span>Open Agents Hub</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        )}
      </div>

      {/* Summary Stats Row Above Pipeline Chart (Prompt vereiste: Summary Stats Row) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-fade-in">
        
        {/* Metric 1: Total Number of Processed Videos for Current Month */}
        <div className="bg-gradient-to-br from-zinc-900 via-zinc-900/90 to-violet-950/40 border border-zinc-800 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-xl hover:border-violet-500/50 transition-all">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span className="font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5 text-zinc-300">
              <Calendar className="w-3.5 h-3.5 text-violet-400" />
              <span>Verwerkte Video&apos;s ({currentMonthName})</span>
            </span>
            <span className="text-[10px] bg-violet-950/90 text-violet-300 border border-violet-800/80 px-2 py-0.5 rounded-full font-bold">
              Deze Maand
            </span>
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              {currentMonthTotalVideos.toLocaleString('nl-NL')}
            </span>
            <span className="text-xs text-zinc-400 font-medium">video&apos;s</span>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1 border-t border-zinc-800/60 font-mono">
            <span className="flex items-center space-x-1 text-emerald-400">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>+18.4% vs vorige maand</span>
            </span>
            <span className="text-zinc-500">Auto-pipeline</span>
          </div>
        </div>

        {/* Metric 2: Overall Success Percentage for Current Month */}
        <div className="bg-gradient-to-br from-zinc-900 via-zinc-900/90 to-emerald-950/40 border border-zinc-800 p-5 rounded-3xl space-y-2 relative overflow-hidden shadow-xl hover:border-emerald-500/50 transition-all">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span className="font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5 text-zinc-300">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Succespercentage ({currentMonthName})</span>
            </span>
            <span className="text-[10px] bg-emerald-950/90 text-emerald-300 border border-emerald-800/80 px-2 py-0.5 rounded-full font-bold">
              Norm &gt;95%
            </span>
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-3xl sm:text-4xl font-black text-emerald-400 font-mono tracking-tight">
              {currentMonthSuccessPercentage}%
            </span>
            <span className="text-xs text-emerald-500/80 font-medium font-mono">geslaagd</span>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full transition-all duration-1000" 
              style={{ width: `${currentMonthSuccessPercentage}%` }} 
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-0.5 font-mono">
            <span className="text-emerald-300">
              {currentMonthSuccessVideos.toLocaleString('nl-NL')} geslaagd
            </span>
            <span className="text-red-400">
              {currentMonthFailedVideos} mislukt
            </span>
          </div>
        </div>

        {/* Metric 3: Gemiddelde Verwerkingstijd */}
        <div className="bg-zinc-900/80 border border-zinc-800 p-5 rounded-3xl space-y-2 shadow-xl hover:border-zinc-700 transition-all">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span className="font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5 text-zinc-300">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              <span>Gem. Verwerkingstijd</span>
            </span>
            <span className="text-[10px] text-zinc-500 font-mono">AI &amp; GPU</span>
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              28.4s
            </span>
            <span className="text-xs text-zinc-400 font-medium">per clip</span>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1 border-t border-zinc-800/60 font-mono">
            <span className="text-zinc-300">fal.ai &amp; MediaPipe</span>
            <span className="text-emerald-400">3x sneller dan realtime</span>
          </div>
        </div>

        {/* Metric 4: Pijplijn Uptime & Alert Status */}
        <div className="bg-zinc-900/80 border border-zinc-800 p-5 rounded-3xl space-y-2 shadow-xl hover:border-zinc-700 transition-all">
          <div className="flex items-center justify-between text-xs text-zinc-400">
            <span className="font-semibold uppercase tracking-wider text-[11px] flex items-center space-x-1.5 text-zinc-300">
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
              <span>Pijplijn Gezondheid</span>
            </span>
            <span className="text-[10px] bg-emerald-950/80 text-emerald-300 border border-emerald-800/80 px-2 py-0.5 rounded-full font-bold">
              Optimaal
            </span>
          </div>

          <div className="flex items-baseline space-x-2">
            <span className="text-3xl sm:text-4xl font-black text-white font-mono tracking-tight">
              99.98%
            </span>
            <span className="text-xs text-emerald-400 font-medium font-mono">uptime</span>
          </div>

          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1 border-t border-zinc-800/60 font-mono">
            <span className="flex items-center space-x-1 text-zinc-300">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>5 entiteiten actief</span>
            </span>
            <span className="text-amber-400">{alerts.filter(a => !a.dismissed).length} alerts</span>
          </div>
        </div>

      </div>

      {/* 30-Day Pipeline Reliability Visualization (Prompt Vereiste 1: Recharts Visualisatie) */}
      <div className="bg-zinc-900/80 border border-zinc-800 rounded-3xl p-6 space-y-5 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
          <div className="space-y-1">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-extrabold text-white">Pijplijn Betrouwbaarheid (Laatste 30 Dagen)</h3>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800/60 px-2 py-0.5 rounded-full font-bold">
                Live Telemetrie
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Vergelijking van de <strong>Render Success Rate (%)</strong> ten opzichte van <strong>Mislukte Pogingen (Failed Attempts)</strong>.
            </p>
          </div>

          {/* Quick Aggregate Badges */}
          <div className="flex items-center space-x-3 text-xs">
            <div className="bg-zinc-950/70 border border-zinc-800 px-3 py-1.5 rounded-xl">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">30d Gem. Succes</span>
              <span className="text-sm font-black text-emerald-400 font-mono">{avg30DaySuccess}%</span>
            </div>
            <div className="bg-zinc-950/70 border border-zinc-800 px-3 py-1.5 rounded-xl">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">Mislukte Pogingen</span>
              <span className="text-sm font-black text-red-400 font-mono">{total30DayFails}</span>
            </div>
            <div className="bg-zinc-950/70 border border-zinc-800 px-3 py-1.5 rounded-xl hidden md:block">
              <span className="text-[10px] text-zinc-400 uppercase font-mono block">Totaal Renders</span>
              <span className="text-sm font-black text-white font-mono">{total30DayRenders}</span>
            </div>
          </div>
        </div>

        {/* Recharts Chart Container */}
        <div className="h-64 sm:h-72 w-full pt-2">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={reliabilityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="successRateGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="#27272a" strokeDasharray="3 3" vertical={false} />
              
              <XAxis 
                dataKey="date" 
                stroke="#71717a" 
                fontSize={10} 
                tickLine={false} 
                interval="preserveStartEnd" 
              />
              
              {/* Left Axis: Success Rate % */}
              <YAxis 
                yAxisId="left" 
                stroke="#10b981" 
                domain={[85, 100]} 
                fontSize={10} 
                tickFormatter={(v) => `${v}%`} 
                tickLine={false} 
              />
              
              {/* Right Axis: Failed Attempts Count */}
              <YAxis 
                yAxisId="right" 
                orientation="right" 
                stroke="#f87171" 
                domain={[0, 6]} 
                fontSize={10} 
                tickLine={false} 
              />

              <Tooltip content={<CustomChartTooltip />} />
              <Legend 
                wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} 
                formatter={(value) => <span className="text-zinc-300 font-medium">{value}</span>}
              />

              {/* Area for Render Success Rate (%) */}
              <Area 
                yAxisId="left"
                type="monotone" 
                dataKey="successRate" 
                name="Render Success Rate (%)" 
                stroke="#10b981" 
                strokeWidth={2.5} 
                fillOpacity={1} 
                fill="url(#successRateGradient)" 
              />

              {/* Bar for Failed Attempts */}
              <Bar 
                yAxisId="right"
                dataKey="failedAttempts" 
                name="Mislukte Pogingen (Failed)" 
                fill="#ef4444" 
                radius={[4, 4, 0, 0]} 
                maxBarSize={14} 
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Real-Time Status Overzicht Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">Pipeline Runs Totaal</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-white">{totalRuns}</span>
            <span className="text-xs text-zinc-500 font-medium">workflows</span>
          </div>
          <div className="text-[11px] text-zinc-400 font-mono pt-1">
            Gem. doorlooptijd: <strong className="text-zinc-200">32.4s</strong>
          </div>
        </div>

        <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">Succespercentage</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-emerald-400">{successRate}%</span>
            <span className="text-xs text-emerald-500/80 font-medium font-mono">{successRuns} geslaagd</span>
          </div>
          <div className="w-full bg-zinc-800 h-1.5 rounded-full overflow-hidden mt-1">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${successRate}%` }} />
          </div>
        </div>

        <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">Actief &amp; Wachtend</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-amber-300">{runningRuns}</span>
            <span className="text-xs text-amber-400/80 font-medium">in verwerking</span>
          </div>
          <div className="text-[11px] text-zinc-400 flex items-center space-x-1 pt-1">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping inline-block" />
            <span>fal.ai render &amp; edit actief</span>
          </div>
        </div>

        <div className="bg-zinc-900/80 border border-zinc-800 p-4 rounded-2xl space-y-1">
          <span className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider block">Gefaalde Validaties</span>
          <div className="flex items-baseline space-x-2">
            <span className="text-2xl font-black text-red-400">{failedRuns}</span>
            <span className="text-xs text-red-400/80 font-medium">herstel vereist</span>
          </div>
          <div className="text-[11px] text-zinc-400 pt-1">
            {failedRuns > 0 ? (
              <span className="text-red-300 font-semibold">1-klik herstart beschikbaar</span>
            ) : (
              <span className="text-emerald-400">Alle runs voldoen aan checks</span>
            )}
          </div>
        </div>

      </div>

      {/* Alerts & Notificaties Section (Prompt vereiste: Alerts als entiteit zoals Jess vastloopt of API limiet bereikt) */}
      {activeAlerts.length > 0 && (
        <div className="bg-zinc-900/90 border border-zinc-800 rounded-3xl p-5 space-y-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-zinc-800/80 pb-3">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-amber-400 animate-bounce" />
              <h3 className="text-sm font-bold text-white">Actieve Systeemalerts &amp; API-Limieten ({activeAlerts.length})</h3>
            </div>
            <span className="text-[11px] text-zinc-400">Automatische detectie van vastlopende entiteiten</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {activeAlerts.map(alert => (
              <div 
                key={alert.id}
                className={`p-3.5 rounded-2xl border flex flex-col justify-between space-y-2.5 transition-all ${
                  alert.severity === 'critical'
                    ? 'bg-red-950/30 border-red-800/80 text-red-200'
                    : alert.severity === 'warning'
                    ? 'bg-amber-950/30 border-amber-800/80 text-amber-200'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-300'
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-extrabold uppercase tracking-wide flex items-center space-x-1">
                      {alert.severity === 'critical' ? (
                        <ShieldAlert className="w-3.5 h-3.5 text-red-400" />
                      ) : (
                        <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      )}
                      <span>{alert.entityName}</span>
                    </span>
                    <span className="text-[10px] text-zinc-400 font-mono">{alert.timestamp}</span>
                  </div>
                  <p className="text-xs leading-relaxed text-zinc-200">{alert.message}</p>
                </div>

                <div className="flex items-center justify-between pt-1 border-t border-zinc-800/60 text-xs">
                  {alert.retryable ? (
                    <button
                      onClick={() => handleRetry('run-102')}
                      disabled={Boolean(isRetrying)}
                      className="px-2.5 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] flex items-center space-x-1 cursor-pointer transition-colors"
                    >
                      <RotateCcw className={`w-3 h-3 ${isRetrying ? 'animate-spin' : ''}`} />
                      <span>Herprobeer (Retry)</span>
                    </button>
                  ) : onNavigateToAgents ? (
                    <button
                      onClick={onNavigateToAgents}
                      className="text-[11px] text-violet-400 hover:text-violet-300 underline cursor-pointer"
                    >
                      Beheer Agent Quota →
                    </button>
                  ) : null}

                  <button
                    onClick={() => onDismissAlert(alert.id)}
                    className="text-[10px] text-zinc-400 hover:text-white px-2 py-0.5 rounded bg-zinc-800/60 cursor-pointer"
                  >
                    Sluiten
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Interactive Workflow Runs & Validatie Logs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Workflow Runs List & Filters (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-white flex items-center space-x-2">
              <Filter className="w-4 h-4 text-violet-400" />
              <span>Gemonitorde Content Runs</span>
            </h4>
            
            {/* Filter Pills */}
            <div className="flex items-center space-x-1 text-[11px]">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-2 py-0.5 rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'all' ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Alles
              </button>
              <button
                onClick={() => setStatusFilter('failed')}
                className={`px-2 py-0.5 rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'failed' ? 'bg-red-950 text-red-300 border border-red-800 font-bold' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Mislukt
              </button>
              <button
                onClick={() => setStatusFilter('success')}
                className={`px-2 py-0.5 rounded-lg transition-colors cursor-pointer ${
                  statusFilter === 'success' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Geslaagd
              </button>
            </div>
          </div>

          {/* Runs List */}
          <div className="space-y-3">
            {filteredRuns.map(run => {
              const isSelected = run.id === selectedRun.id;
              const passedChecksCount = run.checks.filter(c => c.passed).length;
              
              return (
                <div
                  key={run.id}
                  onClick={() => setSelectedRunId(run.id)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer space-y-3 ${
                    isSelected
                      ? 'bg-zinc-900 border-violet-500 ring-1 ring-violet-500 shadow-xl'
                      : 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700 hover:bg-zinc-900/80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2">
                        <span className={`px-2 py-0.5 rounded font-bold uppercase text-[9px] tracking-wider ${
                          run.status === 'success'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : run.status === 'failed'
                            ? 'bg-red-950 text-red-300 border border-red-800'
                            : 'bg-amber-950 text-amber-300 border border-amber-800'
                        }`}>
                          {run.status === 'success' ? 'Geslaagd' : run.status === 'failed' ? 'Mislukt' : 'In Uitvoering'}
                        </span>
                        <span className="text-[10px] text-zinc-500 font-mono">{run.startedAt}</span>
                      </div>
                      <h4 className="text-xs font-bold text-white line-clamp-1">{run.workflowName}</h4>
                    </div>

                    <div className="text-right flex-shrink-0">
                      <span className="text-[10px] font-mono text-zinc-400 block">{(run.durationMs / 1000).toFixed(1)}s</span>
                      <span className="text-[10px] text-violet-400 font-bold">{run.socialTarget || 'TikTok'}</span>
                    </div>
                  </div>

                  {/* Stage Progress Tracker: Idea -> Script -> fal.ai -> Edit -> Social */}
                  <div className="grid grid-cols-5 gap-1 pt-1">
                    {STAGE_ORDER.map((stage) => {
                      const isCompleted = run.stagesCompleted.includes(stage);
                      const isFailed = run.failedStage === stage;
                      const isCurrent = run.currentStage === stage && run.status === 'running';

                      return (
                        <div key={stage} className="space-y-1 text-center">
                          <div 
                            className={`h-1.5 rounded-full transition-all ${
                              isFailed 
                                ? 'bg-red-500' 
                                : isCompleted 
                                ? 'bg-emerald-500' 
                                : isCurrent 
                                ? 'bg-amber-400 animate-pulse' 
                                : 'bg-zinc-800'
                            }`}
                          />
                          <span className={`text-[8px] uppercase tracking-tighter truncate block ${
                            isFailed ? 'text-red-400 font-bold' : isCompleted ? 'text-zinc-400' : 'text-zinc-600'
                          }`}>
                            {stage}
                          </span>
                        </div>
                      );
                    })}
                  </div>

                  {/* Bottom summary bar */}
                  <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1 border-t border-zinc-800/60">
                    <span>Validaties: <strong className="text-white">{passedChecksCount}/{run.checks.length} geslaagd</strong></span>
                    {run.status === 'failed' && (
                      <span className="text-red-400 font-semibold flex items-center space-x-1">
                        <XCircle className="w-3.5 h-3.5" />
                        <span>Fout in {run.failedStage}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

        </div>

        {/* Right Column: Detailed Validatie Logs & Step Inspector (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 space-y-6 shadow-2xl">
            
            {/* Header of selected workflow */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-zinc-800 pb-5">
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300">
                    Run ID: {selectedRun.id}
                  </span>
                  <span className="text-xs text-zinc-400 font-mono">Doelplatform: {selectedRun.socialTarget}</span>
                </div>
                <h4 className="text-lg font-extrabold text-white">{selectedRun.workflowName}</h4>
                <p className="text-xs text-zinc-400">
                  Volledige audit log van de kwaliteitsvalidaties voordat doorgifte naar social media plaatsvindt.
                </p>
              </div>

              {selectedRun.status === 'failed' ? (
                <button
                  onClick={() => handleRetry(selectedRun.id)}
                  disabled={Boolean(isRetrying)}
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md cursor-pointer"
                >
                  <RotateCcw className={`w-3.5 h-3.5 ${isRetrying ? 'animate-spin' : ''}`} />
                  <span>Herstart Mislukte Stap ({selectedRun.failedStage})</span>
                </button>
              ) : selectedRun.status === 'pending_check' ? (
                <button
                  onClick={() => onApproveForSocial(selectedRun.id)}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center space-x-1.5 transition-all shadow-md cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Goedkeuren &amp; Publiceren</span>
                </button>
              ) : (
                <span className="px-3 py-1.5 rounded-xl bg-emerald-950/60 text-emerald-300 border border-emerald-800 text-xs font-bold inline-flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Volledig Gevalideerd</span>
                </span>
              )}
            </div>

            {/* Error Message callout if failed */}
            {selectedRun.errorMessage && (
              <div className="p-4 rounded-2xl bg-red-950/40 border border-red-800/80 space-y-1.5">
                <div className="flex items-center space-x-1.5 text-xs font-bold text-red-300">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span>Gedetecteerde Pijplijnfout in &apos;{selectedRun.failedStage}&apos;</span>
                </div>
                <p className="text-xs text-red-200 leading-relaxed font-mono">{selectedRun.errorMessage}</p>
                <div className="pt-1 text-[11px] text-zinc-400">
                  Aanbeveling: Verhoog API concurrency in de Agents Hub of wissel de rendering provider.
                </div>
              </div>
            )}

            {/* Step-by-Step Quality Checks Log (Prompt vereiste: Validatie Logs per stap) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="font-bold text-white uppercase tracking-wider text-[11px]">Validatie Logs per Pijplijnstap</span>
                <span>Drempelwaarde vs. Behaalde Score</span>
              </div>

              <div className="space-y-2.5">
                {selectedRun.checks.map((chk) => {
                  const StageIcon = STAGE_ICONS[chk.stage] || Sliders;

                  return (
                    <div
                      key={chk.id}
                      className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                        chk.passed
                          ? 'bg-zinc-950/60 border-zinc-800/80'
                          : 'bg-red-950/30 border-red-800/80'
                      }`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${
                          chk.passed 
                            ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' 
                            : 'bg-red-950 text-red-400 border border-red-800'
                        }`}>
                          {chk.passed ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
                        </div>

                        <div className="space-y-1">
                          <div className="flex items-center space-x-2">
                            <span className="text-xs font-bold text-white">{chk.name}</span>
                            <span className="text-[9px] uppercase px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-semibold flex items-center space-x-1">
                              <StageIcon className="w-2.5 h-2.5" />
                              <span>{chk.stage}</span>
                            </span>
                          </div>
                          <p className="text-[11px] text-zinc-300 leading-snug">{chk.message}</p>
                        </div>
                      </div>

                      <div className="text-right sm:flex-shrink-0 flex sm:flex-col items-center sm:items-end justify-between border-t sm:border-t-0 pt-2 sm:pt-0 border-zinc-800/60">
                        <div className="flex items-baseline space-x-1">
                          <span className={`text-base font-extrabold font-mono ${
                            chk.passed ? 'text-emerald-400' : 'text-red-400'
                          }`}>
                            {chk.score ?? 0}
                          </span>
                          <span className="text-[10px] text-zinc-500 font-mono">/ min. {chk.threshold}</span>
                        </div>
                        <span className="text-[9px] text-zinc-500 font-mono">{chk.timestamp}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick action bar */}
            <div className="pt-3 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
              <span className="flex items-center space-x-1.5">
                <Info className="w-4 h-4 text-violet-400" />
                <span>Geautomatiseerde gates blokkeren publicatie als een check &lt; drempelwaarde scoort.</span>
              </span>
              {onNavigateToAgents && (
                <button
                  onClick={onNavigateToAgents}
                  className="text-violet-400 hover:text-violet-300 font-semibold cursor-pointer underline"
                >
                  Configureer Validatiedrempels →
                </button>
              )}
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
